﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeper
{
    class Cell
    {
        public bool IsBomb { get; set; }
        public Int32 Value { get; set; }
        public Int32 XPos { get; set; }
        public Int32 YPos { get; set; }

        public Cell()
        {
            // EMTPY
        }
    }
}
