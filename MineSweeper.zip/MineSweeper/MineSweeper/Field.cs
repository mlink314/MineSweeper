﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeper
{
    class Field
    {
        private List<List<Cell>> rows;
        private bool initialized;
        
        public IEnumerable<Cell> Cells 
        {
            get
            {
                List<Cell> ret = new List<Cell>();
                rows.ForEach(column => column.ForEach(cell => ret.Add(cell)));

                return ret;
            }
        }

        public Int32 Columns { get; private set; }
        public Int32 Rows { get; private set; }
        public Int32 BombsPerRow { get; private set; }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="xDim"></param>
        /// <param name="yDim"></param>
        /// <param name="bombsPerRow"></param>
        public Field(Int32 columns, Int32 rows, Int32 bombsPerRow)
        {
            Columns = columns;
            Rows = rows;
            BombsPerRow = bombsPerRow;
            initialized = false;
        }



        /// <summary>
        /// Instantitate cells, populate rows based on Columns, Rows, and BombsPerRow.
        /// Calls helper functions to initialize random bombs and update the Value property
        /// of neigboring cells.
        /// </summary>
        public void Inititalize()
        {
            if (Columns != null && Rows != null && BombsPerRow != null)
            {
                initializeRows();
                randomizeBombLocations();
                updateField();
                initialized = true;
            }
            else
            {
                throw new Exception("Public properties, Columns, Rows, and BombsPerRow must be initialized");
            }
        }



        /// <summary>
        /// Generates a formatted string representation of the field:
        /// -- Bombs are marked with X;
        /// -- All other cells are marked with an integer corresponding to their Value property.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            if (!initialized)
            {
                return "Empty Field. Try calling public method Initialize";
            }

            StringBuilder fieldBldr = new StringBuilder();

            foreach (List<Cell> row in rows)
            {
                row.ForEach(cell => fieldBldr.Append(String.Format("| {0} ", cell.IsBomb ? "X" : cell.Value.ToString())));
                fieldBldr.Append("|");
                fieldBldr.AppendLine();
            }

            return fieldBldr.ToString();
        }

        #region Private Functions

        /// <summary>
        /// Instantiate the appropriate number of cells and insert them in rows.
        /// This will blow up if the public properties are not set (probably with a NullArgumentException)
        /// </summary>
        private void initializeRows()
        {
            rows = new List<List<Cell>>();

            for (int i = 0; i < Rows; ++i)
            {
                List<Cell> tempRow = new List<Cell>();

                for (int j = 0; j < Columns; ++j)
                {
                    Cell tempCell = new Cell();
                    tempCell.IsBomb = false;
                    tempCell.Value = 0;
                    tempCell.XPos = i;
                    tempCell.YPos = j;

                    tempRow.Add(tempCell);
                }

                rows.Add(tempRow);
            }
        }



        /// <summary>
        /// Updates the Value property of cells, based on their proximity to cells with
        /// true IsBomb values.
        /// </summary>
        private void updateField()
        {
            foreach (List<Cell> row in rows)
            {
                // Update values for cells that aren't bombs
                foreach(Cell cell in row.Where(cell => !cell.IsBomb))
                {
                    List<Cell> neighbors = getCellNeighbors(cell) as List<Cell>;

                    // Increment the value of cell, for each neighbor that is a bomb
                    foreach (Cell neighbor in neighbors.Where(n => n != null && n.IsBomb))
                    {
                        ++cell.Value;
                    }
                }
            }
        }



        /// <summary>
        /// Collect the neigbors of cell
        /// </summary>
        /// <param name="cell"></param>
        /// <returns></returns>
        private IEnumerable<Cell> getCellNeighbors(Cell cell)
        {
            List<Cell> ret = new List<Cell>();

            // top-left
            ret.Add(getCell(cell.XPos - 1, cell.YPos + 1));

            // top
            ret.Add(getCell(cell.XPos, cell.YPos + 1));

            // top-right
            ret.Add(getCell(cell.XPos + 1, cell.YPos + 1));

            // left
            ret.Add(getCell(cell.XPos - 1, cell.YPos));

            // right
            ret.Add(getCell(cell.XPos + 1, cell.YPos));

            // bottom-left
            ret.Add(getCell(cell.XPos - 1, cell.YPos - 1));

            // bottom
            ret.Add(getCell(cell.XPos, cell.YPos - 1));

            // bottom-right
            ret.Add(getCell(cell.XPos + 1, cell.YPos - 1));

            return ret;
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <returns></returns>
        private Cell getCell(int row, int col)
        {
            try
            {
                return rows.ElementAt(row).ElementAt(col);
            }
            catch( ArgumentOutOfRangeException e)
            {
                return null;
            }
        }



        /// <summary>
        /// Sets random cells to active bombs, based on BombsPerRow
        /// </summary>
        private void randomizeBombLocations()
        {
            foreach (List<Cell> row in rows)
            {
                SortedSet<int> bombLocations = new SortedSet<int>();
                
                while (bombLocations.Count < BombsPerRow)
                {
                    // Use Random.Next to get a random number between 0 and (Rows - 1) -- Note that firstly, a new Random
                    // is initialized, with a seed generated from the current time.
                    int randomBombLocation = new Random(DateTime.Now.Millisecond).Next(0, Rows - 1);
                    bombLocations.Add(randomBombLocation);
                }

                // sanity check: we check size here, 'cause location is checked implicitly below.
                if (bombLocations.Count != BombsPerRow)
                {
                    throw new Exception("kaka");
                }


                // set the selected cells to bombs
                foreach (int bombLocation in bombLocations)
                {
                    // If the location is invalid this will throw an ArgumentOutOfRangeException.
                    row.ElementAt(bombLocation).IsBomb = true;
                }
            }
        }

        #endregion
    }

}
