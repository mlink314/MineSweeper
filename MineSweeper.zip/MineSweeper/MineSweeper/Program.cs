﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeper
{
    class Program
    {
        static List<int> validateInput(string[] args)
        {
            int paramRows;
            int paramCols;
            int paramBombsPerRow;

            if (args.Length < 3)
            {
                return null;
            }
            else
            {
                try
                {
                    paramRows = Convert.ToInt32(args[0]);
                    paramCols = Convert.ToInt32(args[1]);
                    paramBombsPerRow = Convert.ToInt32(args[2]);

                    if (paramRows < 1 || paramRows > 100 || paramCols < 1 || paramCols > 100 || paramBombsPerRow < 0 || paramBombsPerRow > paramCols)
                    {
                        return null;
                    }
                }
                catch
                {
                    return null;
                }
            }

            return new List<int>() { paramRows, paramCols, paramBombsPerRow };
        }

        static void Main(string[] args)
        {
            String usage = String.Format("{0}\n{1}", "Usage: MineSweeper -rows -columns -bombsPerRow", "Restrictions: Max Size <= 100 x 100; bombsPerRow <= columns");

            List<int> validArgs = validateInput(args);

            if (validArgs == null)
            {
                Console.WriteLine(usage);
                return;
            }

            Field f = new Field(validArgs[0], validArgs[1], validArgs[2]);
            f.Inititalize();
            Console.WriteLine(f);
            Console.ReadKey();
               
        }

    }
}
